<?php
return array (
  'apps' => 'http://www.webasyst.com/download/apps/list/',
  'system' => 'http://www.webasyst.com/download/system/list/',
);
//EOF
