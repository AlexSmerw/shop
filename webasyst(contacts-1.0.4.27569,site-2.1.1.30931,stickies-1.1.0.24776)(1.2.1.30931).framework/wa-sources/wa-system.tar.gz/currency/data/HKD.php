<?php

return array(
    'code' => 'HKD',
    'sign' => '$',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Hong Kong dollar',
    'name' => array(
        array('dollar', 'dollars'),
        'HK$'
    ),
    'frac_name' => array(
        array('cent', 'cents'),
    )
);